package oops.polymorphism;

public class Dog extends Pet{
	
	public void walk() {
		System.out.println("dog is walking");
		
	}

}
