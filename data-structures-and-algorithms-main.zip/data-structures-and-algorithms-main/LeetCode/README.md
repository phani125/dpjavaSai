<p align="center">
  <img src="https://raw.githubusercontent.com/alpha037/Data-Structures-and-Algorithms/main/LeetCode/img/leetcode.png">
</p>

# LeetCode Solutions

This directory contains solutions to **some** of the Easy and Medium [LeetCode](https://leetcode.come/problemset/all) problems.

## Motivation

Let's create free resources for anyone who wants to solve problems!

## Please Note

I'll keep on adding as much solutions as I can and if you want, you can add them too. Check out the [Contributing](https://github.com/alpha037/Data-Structures-and-Algorithms#contributing) section for more info.
