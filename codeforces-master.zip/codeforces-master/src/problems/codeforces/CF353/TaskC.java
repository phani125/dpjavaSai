package problems.codeforces.CF353;

import problems.codeforces.CF353.MyScanner;
import java.io.PrintWriter;

public class TaskC {
    public void solve(int testNumber, MyScanner in, PrintWriter out) {
    }
}
