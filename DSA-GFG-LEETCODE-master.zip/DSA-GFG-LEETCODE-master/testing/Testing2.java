package testing;
import java.util.*;

public class Testing2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
     
        

		
	}
}