package oops.packages.models;

public class Teacher {

	public static void main(String[] args) {
		
		Student obj = new Student("Harry");

		obj.getPassword();
		
		
	}

}
