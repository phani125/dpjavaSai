package oops.interfaces;

public abstract interface Student {

	abstract void study();

}
