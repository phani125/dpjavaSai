package oops.packages;

import java.util.Scanner;

import oops.packages.models.*;

public class MainClass {

	public static void main(String[] args) {
		
		Student obj = new Student("Tom");
		
		obj.getPassword();
		
		Teacher teacher = new Teacher();
		
		Scanner sc = new Scanner(System.in);

	}

}
