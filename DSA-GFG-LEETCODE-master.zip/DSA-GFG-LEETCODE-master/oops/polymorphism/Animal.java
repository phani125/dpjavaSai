package oops.polymorphism;

public class Animal {

	

}
