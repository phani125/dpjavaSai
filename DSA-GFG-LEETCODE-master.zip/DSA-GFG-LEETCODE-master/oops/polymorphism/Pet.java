package oops.polymorphism;

public class Pet extends Animal{

	public void walk() {
		System.out.println("pet is walking");
		
	}

}
