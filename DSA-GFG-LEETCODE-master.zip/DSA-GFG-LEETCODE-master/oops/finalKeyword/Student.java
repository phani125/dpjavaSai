package oops.finalKeyword;

public final class Student {

	int rollNo;
	String name;
	
	public final void getDescription() {
		System.out.println("The Student Name is "+ name);
		
	}
	
}
