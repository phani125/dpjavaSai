package arrays;

public class ArrayIntro {

	public static void main(String[] args) {
		 
//		int marks [] = new int [5];
		
		
//		int marks[];
//		marks = new int[5];
		
		
//		int marks[] ;				//both marks and classes will store arrays values;
//		marks = new int [5];
//		
//		System.out.println(marks[3]);			//by default it stores 0;
		
		
//		int ages [] = {12,45,18,19,69};
//		for(int i=0; i<ages.length; i++)		
//			System.out.println(ages[i]);
		
		
		double marks [] = {55.55,69.69,45.45,19.19,18.18};
		System.out.println(marks.length);
		
		
		
	}

}
