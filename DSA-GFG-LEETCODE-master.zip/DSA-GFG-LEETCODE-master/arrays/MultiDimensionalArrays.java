package arrays;

public class MultiDimensionalArrays {

	public static void main(String[] args) {
		
//		int a[] []  = new int[5] [3];
		
		int b [] [] = {
				{1,2,3,4,5,6},
				{5,6,7,12,10,1,2,3},
				{15,46,23,}
		};	
		System.out.println(b[0][4]);

	}

}
