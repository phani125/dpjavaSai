package operators;

public class Operators {

	public static void main(String[] args) {
		
		int a = 45;
		int b = 55;
		
		int c = a * a + b * b + 2 * a * b;
		
		int d = c;
		
		int x = b/a;
		
		int w = a++;
		
		System.out.println("the requird output is "+d);
		
		System.out.println("divide is "+x);
		
		System.out.println(w);
		
		
	}

}
