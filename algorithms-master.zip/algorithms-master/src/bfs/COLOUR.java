package bfs;

public enum COLOUR 
{
	WHITE,
	GREY,
	BLACK;
}
