package operators;

public class BitwiseOperators {

	public static void main(String[] args) {
	
// BITWISE AND
		int a = 5;
		int b = 6;
		
		int c= a & b;
		System.out.println(c);

//BITWISE OR
		 int x = 13;
		 int y = 10;
		 
		 int z = x | y;
		 System.out.println(z);
	
	}

}
