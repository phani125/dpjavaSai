package interviewQuestions;

import java.util.*;

public class ArraySumDivisiblity {

	public static void main(String[] args) {

		

	}

}
