package oops;

public class Person {

	int age;
	String name;
	
	static String breed  = "Homo Sepiens";
	
	
	
	public static void main(String[] args) {
		
		System.out.println(Math.min(12,59));
		
	}
	
}
