package oops;

public class A {

	class B {
		
		
	}
	
	static class C {
		
			
	}
	
}
