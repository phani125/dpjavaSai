package loops;

public class NestedLoops {

	public static void main(String[] args) {
		
		int i;
		int j;
		
		for(j=1;j<=6;j++) {
			for(i=1;i<=10;i++) {
				System.out.print(i+" ");
			     }
			System.out.println();
				}

		}

	}
