package problems.codeforces.CF353;

import problems.codeforces.CF353.MyScanner;
import java.io.PrintWriter;

public class TaskB
{
    public void solve(int testNumber, MyScanner in, PrintWriter out)
    {
        int n = in.nextInt();
        int a = in.nextInt();
        int b = in.nextInt();
        int c = in.nextInt();
        int d = in.nextInt();
    }
}
