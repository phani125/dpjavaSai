package problems.codeforces.CF355;

import problems.codeforces.CF353.MyScanner;
import java.io.PrintWriter;

public class TaskE {
    public void solve(int testNumber, MyScanner in, PrintWriter out) {
    }
}
