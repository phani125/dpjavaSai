package arrays;

public class ChocolatesProblem {

	public static void main(String[] args) {
		
		

	}

}
