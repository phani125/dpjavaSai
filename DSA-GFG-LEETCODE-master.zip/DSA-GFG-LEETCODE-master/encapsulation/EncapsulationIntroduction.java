package encapsulation;

public class EncapsulationIntroduction {

	public static void main(String[] args) {
		
		Student obj = new Student();

		obj.setAge(54);
		
		System.out.println(obj.getAge());
		
		
	}

}
