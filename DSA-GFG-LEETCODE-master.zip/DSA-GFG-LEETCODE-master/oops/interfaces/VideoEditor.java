package oops.interfaces;

public interface VideoEditor {

	void editVideo();
	
}
