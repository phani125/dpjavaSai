package linkedList;
import java.util.*;

public class MyLListSetFtn {

	public static void main(String[] args) {
		
		LLSetFtn myll = new LLSetFtn();
		
		myll.AddS(1);
		myll.AddS(12);
		myll.AddS(123);
		myll.AddS(1234);
		myll.AddS(12345);
		
		
		myll.Set(2, 20);
		myll.printS();
		
		

	}

}
