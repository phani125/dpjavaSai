package linkedList;
import java.util.*;

public class MyLinkedList {

	public static void main(String[] args) {
		
		LLImplementation<Integer> llist = new LLImplementation<>();
			
			for(int i=0; i<10; i++) {
				llist.Add(i);
			}
		
//		List<Integer> ll = new LinkedList<>();
//		List<Integer> al = new ArrayList<>();
//		getTimeDiff(al);
//		getTimeDiff(ll);
//
//		ll.add(12);
//		ll.add(2);
//		ll.add(32);
//		System.out.println(ll);	
//		
//	}
//	
//	static void getTimeDiff(List<Integer> list) {
//		
//		long start = System.currentTimeMillis();
//		
//		for(int i=0; i<100000; i++) {
//			list.add(0, i);
//		}
//		
//		long end = System.currentTimeMillis();
//			
//		System.out.println(list.getClass().getName() + " --> " + (end - start));
//		}
		
	}
			
}

