package problems.interviewbit;

/**
 * Created by gouthamvidyapradhan on 01/09/2016.
 */
public class MergeOverlappingIntervals
{
    static class Interval
    {
        int i;
        boolean isStart;
        Interval(int i, boolean isStart)
        {
            this.i = i;
            this.isStart = isStart;
        }
    }

    public static void main(String[] args) throws Exception
    {

    }


}
